import { NextResponse } from "next/server";
import { supabase } from "../../../../../../lib/supabaseClient";
import { Resend } from "resend";

const resend = new Resend(process.env.RESEND_API_KEY);

export async function POST(_req: Request, { params }: { params: { id: string } }) {
  const id = params.id;
  const { data, error } = await supabase.from("deals").update({ status: "rejected" }).eq("id", id).select().single();
  if (error) return NextResponse.json({ error: error.message }, { status: 400 });

  const emailTo = data.contact_email;

  await resend.emails.send({
    from: process.env.EMAIL_FROM || "Arrora RBF <onboarding@resend.dev>",
    to: emailTo,
    subject: "Arrora RBF — Submission outcome",
    html: `<p>Thanks for sharing your opportunity. After review, we’re unable to proceed because it does not align with our thesis at this time.</p><p>We appreciate your time.</p><p>— Arrora RBF</p>`,
  });

  return NextResponse.json({ ok: true });
}
