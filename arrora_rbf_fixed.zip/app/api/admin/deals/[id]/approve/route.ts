import { NextResponse } from "next/server";
import { supabase } from "../../../../../../lib/supabaseClient";
import { Resend } from "resend";

const resend = new Resend(process.env.RESEND_API_KEY);

export async function POST(_req: Request, { params }: { params: { id: string } }) {
  const id = params.id;
  const { data, error } = await supabase.from("deals").update({ status: "approved" }).eq("id", id).select().single();
  if (error) return NextResponse.json({ error: error.message }, { status: 400 });

  // Send approval email with pre-DD checklist and NDA link
  const emailTo = data.contact_email;
  const ndaUrl = `${process.env.NEXT_PUBLIC_BASE_URL || ""}/nda.pdf`;

  await resend.emails.send({
    from: process.env.EMAIL_FROM || "Arrora RBF <onboarding@resend.dev>",
    to: emailTo,
    subject: "Arrora RBF — Your submission is approved",
    html: `<h2>Congratulations!</h2>
<p>Your deal submission has been <b>approved</b>. Next steps: please send the following pre-due-diligence items by replying to this email.</p>
<ol>
<li>Company incorporation documents</li>
<li>Latest financial statements (P&L, Balance Sheet, Cashflow)</li>
<li>Customer traction metrics and key contracts</li>
<li>Cap table and any outstanding obligations</li>
<li>Team bios</li>
<li>Growth plan for the next 12 months</li>
</ol>
<p>You can also download our signed NDA here: <a href="${ndaUrl}">NDA (PDF)</a></p>
<p>— Arrora RBF</p>`,
  });

  return NextResponse.json({ ok: true });
}
