"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "../../lib/supabaseClient";

export default function DealFormPage() {
  const router = useRouter();
  const [form, setForm] = useState({ company_name: "", website: "", contact_email: "", amount: "", details: "", nda: false });
  const [loading, setLoading] = useState(false);

  function set<K extends keyof typeof form>(key: K, value: (typeof form)[K]) {
    setForm(prev => ({ ...prev, [key]: value }));
  }

  async function submit(e) {
    e.preventDefault();
    if (!form.nda) return alert("Please agree to the NDA.");
    setLoading(true);
    const { data: userData } = await supabase.auth.getUser();
    const user = userData.user;
    const payload = { ...form, referrer_id: user?.id || null, status: "pending" };
    const { error } = await supabase.from("deals").insert(payload);
    setLoading(false);
    if (error) return alert(error.message);
    alert("Deal submitted! We’ll review and get back to you.");
    router.replace("/");
  }

  return (
    <main className="min-h-screen">
      <div className="container py-10">
        <h1 className="text-3xl font-bold mb-6">Refer a Deal</h1>
        <form onSubmit={submit} className="grid md:grid-cols-2 gap-4 card p-6">
          <input placeholder="Company Name" value={form.company_name} onChange={e => set("company_name", e.target.value)} required />
          <input placeholder="Website" value={form.website} onChange={e => set("website", e.target.value)} />
          <input type="email" placeholder="Contact Email" value={form.contact_email} onChange={e => set("contact_email", e.target.value)} required />
          <input placeholder="Funding Amount (USD)" value={form.amount} onChange={e => set("amount", e.target.value)} />
          <textarea placeholder="Brief details" className="md:col-span-2" rows={4} value={form.details} onChange={e => set("details", e.target.value)} />
          <label className="flex items-center gap-2 md:col-span-2">
            <input type="checkbox" checked={form.nda} onChange={e => set("nda", e.target.checked)} />
            <span>I agree to the NDA. <a href="/nda.pdf" target="_blank" rel="noreferrer" className="underline">Read/Download NDA</a></span>
          </label>
          <div className="md:col-span-2">
            <button disabled={loading} className="bg-brand-600 text-white px-4 py-2 rounded-2xl">{loading ? "Submitting..." : "Submit Deal"}</button>
          </div>
        </form>
      </div>
    </main>
  );
}
