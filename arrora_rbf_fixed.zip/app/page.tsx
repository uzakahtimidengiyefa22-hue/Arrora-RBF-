"use client";
import Header from "../components/Header";
import { useRouter } from "next/navigation";
import { supabase } from "../lib/supabaseClient";
import { useEffect, useState } from "react";

export default function LandingPage() {
  const router = useRouter();
  const [session, setSession] = useState(null);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => setSession(s));
    return () => sub.subscription.unsubscribe();
  }, []);

  return (
    <main className="min-h-screen flex flex-col">
      <Header centerLogo />
      <section className="bg-brand-600 text-white">
        <div className="container py-16 text-center">
          <h1 className="text-4xl font-bold mb-4">Revenue-Based Funding for Real Growth</h1>
          <p className="max-w-2xl mx-auto text-lg opacity-90">
            Arrora RBF provides startups, companies and SMEs with access to the capital they need to scale —
            without tying them down with equity like traditional VC models.
          </p>
          <button
            onClick={() => router.push(session ? "/deal" : "/login?redirect=/deal")}
            className="mt-8 bg-white text-brand-600 font-semibold px-6 py-3 rounded-2xl"
          >
            Refer A Startup
          </button>
        </div>
      </section>
      <section className="container py-16" id="why">
        <h2 className="text-3xl font-bold text-center mb-8">Why Choose Us</h2>
        <div className="grid md:grid-cols-3 gap-6">
          <div className="card p-6">
            <h3 className="font-semibold mb-2">Non-Dilutive</h3>
            <p>Keep your equity. We fund growth based on revenues, not board seats.</p>
          </div>
          <div className="card p-6">
            <h3 className="font-semibold mb-2">Fast Decisions</h3>
            <p>Streamlined underwriting, minimal paperwork, and quick turnarounds.</p>
          </div>
          <div className="card p-6">
            <h3 className="font-semibold mb-2">Aligned Incentives</h3>
            <p>We grow when you grow. Repayments are tied to future performance.</p>
          </div>
        </div>
      </section>
      <section className="bg-gray-50" id="contact">
        <div className="container py-12">
          <h2 className="text-2xl font-bold mb-4">Contact</h2>
          <p>Email: <a href="mailto:uzakahtimidengiyefa22@gmail.com" className="underline">uzakahtimidengiyefa22@gmail.com</a></p>
          <p>Phone: <a href="tel:07016312955" className="underline">07016312955</a></p>
        </div>
      </section>
    </main>
  );
}
